/*
 * @Author: error: git config user.name && git config user.email & please set dead value or install git
 * @Date: 2023-01-06 20:38:59
 * @LastEditors: error: git config user.name && git config user.email & please set dead value or install git
 * @LastEditTime: 2023-01-07 00:06:44
 * @FilePath: \RVMDK（uv5）x:\工程模板（freertos） - 副本\User\pp_time.h
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
#ifndef __TIME____

#define __TIME____

#include "stm32f10x.h"

void TIMX_Delay_Init(uint32_t ClOCK, uint16_t TIM_PERIOD, uint16_t TIM_PRESCALER, TIM_TypeDef *TIMX);
void TIMX_Delayus(TIM_TypeDef *TIMX, u16 xus);
void TIMX_Delayms(TIM_TypeDef *TIMX, u16 xms);

#endif
