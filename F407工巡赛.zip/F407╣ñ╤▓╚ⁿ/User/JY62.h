#ifndef JY62__
#define JY62__
#include "stm32f4xx.h"
#include <string.h>
#define EN_JY62 1
#define JY62_USARTX UART4
#define JY62_IRQHandler UART4_IRQHandler

struct SGyro
{
    short w[3];
    short T;
};
struct SAcc
{
    short a[3];
    short T;
};

struct SAngle
{
    short Angle[3]; //! 原始角度数据，读出来后需要转发 例：Angal_X = (float)stcAngle.Angle[2] / 32768 * 180;
    short T;
};

void sendcmd(const char cmd[]);
void UART2_Put_Char(unsigned char DataToSend);
static void NVIC_USART4_Configuration(void);
void USART4_Config_JY62(void);
extern struct SAcc stcAcc;
extern struct SGyro stcGyro;
extern struct SAngle stcAngle;
#endif
