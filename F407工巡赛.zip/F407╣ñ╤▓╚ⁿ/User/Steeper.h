#ifndef Steep
#define Steep
#include "stm32f4xx.h"


void Set_Plus(u16 steep);
void Steeper_Steep(void);

#endif 
